#!/bin/bash

# MongoDB source server connection string URI
SOURCE_URI="mongodb://root%40Admin:7r8h3e8Y%24Q%23A@37.60.242.154:27017/?authSource=admin"

# MongoDB destination server connection string URI
DEST_URI="mongodb://TE%40Admin:7r8h3e8Y%24Q%23A@185.100.212.51:27017/?authSource=admin"

# Specify the collection names and their conditions for migration
COLLECTIONS=("changes:{\"_environmentId\": \"64d5efdfbbec5805b9967722\", \"_organizationId\": \"64d5efdfbbec5805b996771c\"}" "layouts:{\"_environmentId\": \"64d5efdfbbec5805b9967722\", \"_organizationId\": \"64d5efdfbbec5805b996771c\"}" "messagetemplates:{\"_environmentId\": \"64d5efdfbbec5805b9967722\", \"_organizationId\": \"64d5efdfbbec5805b996771c\"}")

# Step 1: Backup selected collections based on conditions from the source database
echo "Creating backup of collections based on conditions from the source database..."
for item in "${COLLECTIONS[@]}"; do
  collection=$(echo "$item" | cut -d ':' -f 1)
  query=$(echo "$item" | cut -d ':' -f 2)
  mongodump --uri "$SOURCE_URI" --out /path/to/backup/directory --collection "$collection" --query "$query"
done

# Step 2: Transfer backup to destination server
echo "Transferring backup files to the destination server..."
scp -r /path/to/backup/directory user@<destination_host>:/path/to/destination/directory

# Step 3: Restore backup on destination server
echo "Restoring backup on the destination server..."
ssh user@<destination_host> "mongorestore --uri $DEST_URI /path/to/destination/directory"

echo "Migration completed successfully!"
