#!/bin/bash

# Define color variables for terminal output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color

# Define database variables
SOURCE_DB="test"
DESTINATION_DB="test"

# MongoDB source server connection string URI
SOURCE_URI="mongodb://root%40Admin:7r8h3e8Y%24Q%23A@37.60.242.154:27017/?authSource=admin"

# MongoDB destination server connection string URI
TARGET_URI="mongodb://TE%40Admin:7r8h3e8Y%24Q%23A@185.100.212.51:27017/?authSource=admin"

# Step 1: Fetch organizations with associated admin names from the source database
echo -e "${GREEN}Fetching organizations with associated admin names from the source database...${NC}"
organizations_with_admins=$(mongosh "$SOURCE_URI" --db "$SOURCE_DB" --quiet --eval 'db.organizations.aggregate([
  {
    $lookup: {
      from: "members",
      localField: "_id",
      foreignField: "_organizationId",
      as: "admins",
    },
  },
  {
    $unwind: "$admins",
  },
  {
    $lookup: {
      from: "users",
      localField: "admins._userId",
      foreignField: "_id",
      as: "admin_users",
    },
  },
  {
    $match: {
      "admins.roles": "admin",
      "admins.memberStatus": "active",
      "admin_users": { $ne: [] }
    }
  },
  {
    $project: {
      _id: 1,
      name: 1,
      adminName: {
        $arrayElemAt: [
          "$admin_users.firstName",
          0,
        ],
      },
      adminLastName: {
        $arrayElemAt: [
          "$admin_users.lastName",
          0,
        ],
      },
      adminEmail: {
        $arrayElemAt: ["$admin_users.email", 0],
      },
    },
  },
]).toArray()')

# Display available organizations with admin names for selection
echo -e "${GREEN}Available organizations with associated admin names for migration:${NC}"
echo "$organizations_with_admins"

# Prompt user to select an organization
read -p "$(echo -e "${YELLOW}Enter the name of the organization you want to migrate:${NC} ")" selected_organization

# Step 2: Fetch environments for the selected organization
echo -e "${GREEN}Fetching environments for the selected organization...${NC}"
environments=$(mongosh "$SOURCE_URI" --db "$SOURCE_DB" --quiet --eval "db.environments.find({_organizationId: ObjectId('$selected_organization')}, {_id: 1, name: 1}).toArray()")

# Display available environments for selection
echo -e "${GREEN}Available environments for migration:${NC}"
echo "$environments"

# Prompt user to select an environment
read -p "$(echo -e "${YELLOW}Enter the name of the environment you want to migrate:${NC} ")" selected_environment

orgIDStr="ObjectId(\"$selected_organization\")"
envIDStr="ObjectId(\"$selected_environment\")"
envOrgJson="{\"_environmentId\": {\"\$oid\": \"$selected_environment\"}, \"_organizationId\": {\"\$oid\": \"$selected_organization\"}}"

# Specify the collection names and their conditions for migration
COLLECTIONS=("changes@$envOrgJson" "layouts@$envOrgJson" "messagetemplates@$envOrgJson" "notificationtemplates@$envOrgJson")

# Step 1: Backup selected collections based on conditions from the source database
echo -e "${GREEN}Creating backup of collections based on conditions from the source database...${NC}"
for item in "${COLLECTIONS[@]}"; do
  collection=$(echo "$item" | cut -d '@' -f 1)
  echo -e "${YELLOW}Itrating COLLECTION $collection${NC} "
  query=$(echo "$item" | cut -d '@' -f 2)
  echo -e "${YELLOW}Itrating QUERY $query...${NC} "
  echo "mongoexport --uri \"$SOURCE_URI\" --collection \"$collection\" --query \"$query\" --out \"./exportDir/$collection.json\""
  mongoexport --uri "$SOURCE_URI" --collection "$collection" --query "$query" --out "./exportDir/$collection.json"
done


# Step 3: Restore backup on destination server
echo -e "${GREEN}Restoring backup on the destination server...${NC}"
for item in "${COLLECTIONS[@]}"; do
  collection=$(echo "$item" | cut -d '@' -f 1)
  echo -e "${YELLOW}Itrating COLLECTION $collection${NC} "
  query=$(echo "$item" | cut -d '@' -f 2)
  echo -e "${YELLOW}Itrating QUERY $query...${NC} "

  echo "mongoimport --uri \"$TARGET_URI\" --collection \"$collection\" --file \"./exportDir/$collection.json\" --upsert"
  # Uncomment the below line once you are sure the command is correct
  mongoimport --uri "$TARGET_URI" --collection "$collection" --file "./exportDir/$collection.json" --upsert
done

echo -e "${GREEN}Migration completed successfully!${NC}"
