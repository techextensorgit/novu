#!/bin/bash

# Define color variables for terminal output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color

# Define database variables
SOURCE_DB="test"
DESTINATION_DB="test"

# MongoDB source server connection string URI
SOURCE_URI="mongodb://root%40Admin:7r8h3e8Y%24Q%23A@37.60.242.154:27017/?authSource=admin"

# MongoDB destination server connection string URI
TARGET_URI="mongodb://TE%40Admin:7r8h3e8Y%24Q%23A@185.100.212.51:27017/?authSource=admin"


# Prompt user for migration type
options=("Existing" "New")
PS3="Select migration type (enter the number): "
select option in "${options[@]}"; do
  case "$REPLY" in
    1) migration_type="Existing"; break ;;
    2) migration_type="New"; break ;;
    *) echo -e "${RED}Invalid option. Please select 1 or 2.${NC}" ;;
  esac
done


# Step 1: Fetch organizations with associated admin names from the source database
echo -e "${GREEN}Fetching organizations with associated admin names from the source database...${NC}"
organizations_with_admins=$(mongosh "$SOURCE_URI" --db "$SOURCE_DB" --quiet --eval 'db.organizations.aggregate([
  {
    $lookup: {
      from: "members",
      localField: "_id",
      foreignField: "_organizationId",
      as: "admins",
    },
  },
  {
    $unwind: "$admins",
  },
  {
    $lookup: {
      from: "users",
      localField: "admins._userId",
      foreignField: "_id",
      as: "admin_users",
    },
  },
  {
    $match: {
      "admins.roles": "admin",
      "admins.memberStatus": "active",
      "admin_users": { $ne: [] }
    }
  },
  {
    $project: {
      _id: 1,
      name: 1,
      adminID: {
        $arrayElemAt: [
          "$admin_users._id",
          0,
        ],
      },
      adminName: {
        $arrayElemAt: [
          "$admin_users.firstName",
          0,
        ],
      },
      adminLastName: {
        $arrayElemAt: [
          "$admin_users.lastName",
          0,
        ],
      },
      adminEmail: {
        $arrayElemAt: ["$admin_users.email", 0],
      },
    },
  },
]).toArray()')

# Display available organizations with admin names for selection
echo -e "${GREEN}Available organizations with associated admin names for migration:${NC}"
echo "$organizations_with_admins"


# data_modified=$(echo "$organizations_with_admins" | sed "s/\([^ ]\+\):/'\1':/g")

# echo "data_modified"
# echo "$data_modified"
# Function to add single quotes before words preceding a colon
add_single_quotes() {
  local input="$1"
  # Use sed to match the pattern and add single quotes
  # For specific fields like "_id", handle them differently
  # output=$(echo "$input" | sed -E "s/([a-zA-Z0-9_]+):([^O][a-zA-Z0-9]+)/'\1': '\2'/g" | sed -E "s/(ObjectId\('')/ObjectId\(\"\"')/g" | sed -E "s/(ObjectId\('([^)]+)')/ObjectId\('\2\"'/g")

  output=$(echo "$input" | sed -E "s/([a-zA-Z0-9]+):/'\1':/")
  output=$(echo "$output" | sed "s/_'id'/'_id'/")

  echo "$output"
}


# Call the function with the input string
# # json_output=$(echo "$data_modified" | jq '.')
data_modified=$(add_single_quotes "$organizations_with_admins")
echo "data_modified"
echo "$data_modified"
json_output=$(echo "$data_modified" | jq '.')
echo "json_output"
echo "json_output"
echo "$json_output"



# Prompt user to select an organization
read -p "$(echo -e "${YELLOW}Enter the ID of the organization you want to migrate:${NC} ")" selected_organization

if [[ "$migration_type" == "Existing" ]]; then
  # Step 2: Fetch environments for the selected organization
  echo -e "${GREEN}Fetching environments for the selected organization...${NC}"
  environments=$(mongosh "$SOURCE_URI" --db "$SOURCE_DB" --quiet --eval "db.environments.find({_organizationId: ObjectId('$selected_organization')}, {_id: 1, name: 1}).toArray()")
  # Display available environments for selection
  echo -e "${GREEN}Available environments for migration:${NC}"
  echo "$environments"
else
    

    for item in "${organizations_with_admins[@]}"; do
      echo "\n\n--------------------------------------------------------"
      echo ${organizations_with_admins[$item,adminID]}
      # if [[ ${organizations_with_admins[$key,_id]} -eq $selected_organization ]]; then
      #     echo "Name: ${organizations_with_admins[$key,adminID]}"
      # fi
    
    done
fi

orgIDStr="ObjectId(\"$selected_organization\")"
envIDStr="c"
userIDStr="ObjectId(\"$selected_environment\")"
# Initialize envOrgJson variable based on migration type
if [[ "$migration_type" == "Existing" ]]; then
  # Prompt user to select an environment
  read -p "$(echo -e "${YELLOW}Enter the ID of the environment you want to migrate:${NC} ")" selected_environment
  envOrgJson="{\"_environmentId\": {\"\$oid\": \"$selected_environment\"}, \"_organizationId\": {\"\$oid\": \"$selected_organization\"}}"
else
  envOrgJson="{\"_organizationId\": {\"\$oid\": \"$selected_organization\"}}"
fi

# Initialize COLLECTIONS array based on migration type
if [[ "$migration_type" == "Existing" ]]; then
  # Construct COLLECTIONS array with formatted entries
  COLLECTIONS=("changes@$envOrgJson" "layouts@$envOrgJson" "messagetemplates@$envOrgJson" "notificationtemplates@$envOrgJson")
else
  # Directly list collections for New migration type with @$envOrgJson formatting
  COLLECTIONS=("messagetemplates@$envOrgJson" "notificationgroups@$envOrgJson" "notifications@$envOrgJson" "notificationtemplates@$envOrgJson" "organizations@$envOrgJson" "subscriberpreferences@$envOrgJson" "subscribers@$envOrgJson" "tenants@$envOrgJson" "topics@$envOrgJson" "topicsubscribers@$envOrgJson")
fi



# Step 1: Backup selected collections based on conditions from the source database
echo -e "${GREEN}Creating backup of collections based on conditions from the source database...${NC}"
for item in "${COLLECTIONS[@]}"; do
  collection=$(echo "$item" | cut -d '@' -f 1)
  echo -e "${YELLOW}Itrating COLLECTION $collection${NC} "
  query=$(echo "$item" | cut -d '@' -f 2)
  echo -e "${YELLOW}Itrating QUERY $query...${NC} "
  echo "mongoexport --uri \"$SOURCE_URI\" --collection \"$collection\" --query \"$query\" --out \"./exportDir/$collection.json\""
  mongoexport --uri "$SOURCE_URI" --collection "$collection" --query "$query" --out "./exportDir/$collection.json"
done


# Step 3: Restore backup on destination server
echo -e "${GREEN}Restoring backup on the destination server...${NC}"
for item in "${COLLECTIONS[@]}"; do
  collection=$(echo "$item" | cut -d '@' -f 1)
  echo -e "${YELLOW}Itrating COLLECTION $collection${NC} "
  query=$(echo "$item" | cut -d '@' -f 2)
  echo -e "${YELLOW}Itrating QUERY $query...${NC} "

  echo "mongoimport --uri \"$TARGET_URI\" --collection \"$collection\" --file \"./exportDir/$collection.json\" --upsert"
  # Uncomment the below line once you are sure the command is correct
  mongoimport --uri "$TARGET_URI" --collection "$collection" --file "./exportDir/$collection.json" --upsert
done

echo -e "${GREEN}Migration completed successfully!${NC}"