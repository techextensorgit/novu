import os
import subprocess
import json
from bson import ObjectId
from getpass import getpass
import re
import pymongo

# Define color variables for terminal output
class colors:
    RED = '\033[0;31m'
    GREEN = '\033[0;32m'
    YELLOW = '\033[0;33m'
    NC = '\033[0m' # No Color

# Define database variables
SOURCE_DB = "test"
DESTINATION_DB = "test"

# MongoDB source server connection string URI
SOURCE_URI = "mongodb://root%40Admin:7r8h3e8Y%24Q%23A@37.60.242.154:27017/?authSource=admin"

# MongoDB destination server connection string URI
TARGET_URI = "mongodb://TE%40Admin:7r8h3e8Y%24Q%23A@185.100.212.51:27017/?authSource=admin"

print(f'{colors.YELLOW}Select migration type (enter the number):{colors.NC}')
options = ["Existing", "New"]
for i, option in enumerate(options, start=1):
    print(f'{i}. {option}')

while True:
    try:
        migration_type = options[int(input()) - 1]
        break
    except (ValueError, IndexError):
        print(f'{colors.RED}Invalid option. Please select 1 or 2.{colors.NC}')

# Define the MongoDB aggregation pipeline as a list of stages
pipeline = [
    {
        "$lookup": {
            "from": "members",
            "localField": "_id",
            "foreignField": "_organizationId",
            "as": "admins"
        }
    },
    {
        "$unwind": "$admins"
    },
    {
        "$lookup": {
            "from": "users",
            "localField": "admins._userId",
            "foreignField": "_id",
            "as": "admin_users"
        }
    },
    {
        "$match": {
            "admins.roles": "admin",
            "admins.memberStatus": "active",
            "admin_users": {"$ne": []}
        }
    },
    {
        "$project": {
            "_id": 1,
            "name": 1,
            "adminID": {"$arrayElemAt": ["$admin_users._id", 0]},
            "adminName": {"$arrayElemAt": ["$admin_users.firstName", 0]},
            "adminLastName": {"$arrayElemAt": ["$admin_users.lastName", 0]},
            "adminEmail": {"$arrayElemAt": ["$admin_users.email", 0]}
        }
    }
]

def execute_mongodb_aggregation(uri, db_name, pipeline):
    try:
        client = pymongo.MongoClient(uri)
        db = client[db_name]
        result = list(db.organizations.aggregate(pipeline))
        return result
    except Exception as e:
        print(f"Error executing MongoDB aggregation: {e}")
        return None
    finally:
        client.close()
def execute_env_aggregation(uri, db_name, pipeline):
    try:
        client = pymongo.MongoClient(uri)
        db = client[db_name]
        result = list(db.environments.aggregate(pipeline))
        return result
    except Exception as e:
        print(f"Error executing MongoDB aggregation: {e}")
        return None
    finally:
        client.close()

# Execute the MongoDB aggregation pipeline
organizations_with_admins = execute_mongodb_aggregation(SOURCE_URI, SOURCE_DB, pipeline)

def find_organization(org_id):
    for org in organizations_with_admins:
        print("organizations_json:",org["_id"],org_id)
        if org["_id"] == ObjectId(org_id):
            return org
    return None
if organizations_with_admins:
    organizations_json = json.dumps(organizations_with_admins, default=str)
    print(f"{colors.GREEN}Available organizations with associated admin names for migration:{colors.NC}")
    print(organizations_json)

    selected_organization = input(f'{colors.YELLOW}Enter the ID of the organization you want to migrate:{colors.NC} ')
    # Function to find organization by ID

    # Example: Accessing organization with ID "org1"

    specific_org = find_organization(selected_organization)


    # Check if the organization is found and print its details
    if specific_org:
        print("Found organization:")
        print(specific_org)

        if migration_type == "Existing":
            # Fetch environments for the selected organization
            
            env_pipeline = [
                {
                    '$match': {
                        '_organizationId': ObjectId(selected_organization)
                    },                    
                    # "$project":
                    # {
                    #     "_id": 1,
                    #     "name": 1,
                    # },
                    
                }
            ]

            # Execute the MongoDB aggregation pipeline to fetch environments
            environments_json = execute_env_aggregation(SOURCE_URI, SOURCE_DB, env_pipeline)

            # Display available environments for migration
            print(f"{colors.GREEN}Available environments for migration:{colors.NC}")
            print(environments_json)
        else:
            # Extract admin ID from the specific organization
            admin_id = specific_org.get('_id')
            # Connect to the source MongoDB server
            source_client = pymongo.MongoClient(SOURCE_URI)
            source_db = source_client[SOURCE_DB]

            # Fetch the user based on adminID
            user = source_db.organizations.find_one({"_id": ObjectId(selected_organization)})

            if user:
                print(f"{colors.GREEN}Found organizations with adminID '{admin_id}':{colors.NC}")
                print(user)

                # Connect to the destination MongoDB server
                target_client = pymongo.MongoClient(TARGET_URI)
                target_db = target_client[DESTINATION_DB]
               
                target_db.organizations.insert_one(user)
                print(f"{colors.GREEN}organizations with ID '{selected_organization}' inserted into the destination database.{colors.NC}")
                target_client.close()
            else:
                print(f"{colors.RED}organizations with ID '{selected_organization}' not found in the source database.{colors.NC}")

            source_client.close()

        if migration_type == "Existing":
            environments = input(f'{colors.YELLOW}Enter the ID of the environment you want to migrate:{colors.NC} ')
            envOrgJson = {"_environmentId": {"$oid": environments}, "_organizationId": {"$oid": selected_organization}}
            # envOrgJson = {"_environmentId": ObjectId(environments), "_organizationId": ObjectId(selected_organization)}
            
            collection_list = ["changes", "layouts", "messagetemplates", "notificationtemplates"]
        else:
            envOrgJson = {"_organizationId": {"$oid": selected_organization}}
            collection_list = [
                                "environments",
                                "executiondetails",
                                "feeds",
                                # "integrations",
                                "jobs",
                                "layouts",
                                "logs",
                                "members",
                                "messages",
                                "messagetemplates",
                                "notificationgroups",
                                "notifications",
                                "notificationtemplates",
                                "organizations",
                                # "subscriberpreferences",
                                # "subscribers",
                                "tenants",
                                "test",
                                "topics",
                                # "topicsubscribers",
                                "users"
                                ]



        
        print(f'{colors.GREEN}Creating backup of collections based on conditions from the source database...{colors.NC}')
        for collection in collection_list:
            query = json.dumps(envOrgJson)
            cmd = f'mongoexport --uri \"{SOURCE_URI}\" --collection \"{collection}\" --query \'{query}\' --out \"./exportDir/{collection}.json\"'
            subprocess.run(cmd, shell=True)
            print(f'{colors.GREEN}mongoexport successfully:{collection}{colors.NC}')

        print(f'{colors.GREEN}Restoring backup on the destination server...{colors.NC}')
        for collection in collection_list:
            cmd = f'mongoimport --uri \"{TARGET_URI}\" --collection \"{collection}\" --file \"./exportDir/{collection}.json\" --upsert'
            subprocess.run(cmd, shell=True)
            print(f'{colors.GREEN}mongoimport successfully:{collection}{colors.NC}')

        print(f'{colors.GREEN}Migration completed successfully!{colors.NC}')
    else:
        print(f"Organization with ID '{selected_organization}' not found.")
else:
    print("Error executing MongoDB aggregation.")
